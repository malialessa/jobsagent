/**
 *  * ====================================================================================
  * ARQUITETURA E GUIA DE SOBREVIVÊNCIA DA BASE DE CONHECIMENTO (IA)
   * ====================================================================================
    * 
     * Este guia documenta as decisões críticas de arquitetura e as lições aprendidas
      * durante a implementação da busca vetorial, para evitar erros futuros.
       *
        * --- ARQUITETURA DE FLUXO DE DADOS ---
         * 
          * 1.  UPLOAD -> 2. PROCESSAMENTO E EMBEDDING -> 3. ARMAZENAMENTO DE VETORES -> 4. BUSCA E CONSULTA
           * (O fluxo detalhado está descrito nos comentários do código abaixo)
            *
             * --- PADRONIZAÇÃO DE MODELOS DE IA (Válido em Out/2025) ---
              * 
               * -   MODELO DE EMBEDDING: `text-embedding-004`. Otimizado para gerar representações numéricas
                *     de texto para tarefas de busca e recuperação.
                 * 
                  * -   MODELO GENERATIVO (LLM): Para tarefas que exigem raciocínio, análise e geração de texto
                   *     (como `/analisarErroComIA`), padronizamos o uso do modelo estável mais avançado da família Gemini: `gemini-2.5-pro`.
                    *     É crucial verificar a documentação oficial periodicamente para confirmar os nomes dos modelos estáveis,
                     *     pois os nomes de "preview" são descontinuados rapidamente.
                      *
                       * --- LIÇÕES CRÍTICAS APRENDIDAS (NÃO ALTERAR SEM LER!) ---
                        * 
                         * 1.  A API DE EMBEDDING DO VERTEX AI (`embed...REST`):
                          *     -   PROBLEMA: Erros `404 Not Found`.
                           *     -   CAUSA: Uso de sintaxe de API antiga (`:embedContent`) para chamar um modelo novo (`text-embedding-004`)
                            *       que exige a sintaxe moderna (`:predict`).
                             *     -   SOLUÇÃO: Código atualizado para usar o endpoint `:predict` e o corpo `{"instances": ...}`.
                              *
                               * 2.  A FUNÇÃO `VECTOR_SEARCH` DO BIGQUERY (`/assistenteSprint`):
                                *     -   PROBLEMA: Erros de sintaxe SQL como `Name id not found inside base`.
                                 *     -   CAUSA: `VECTOR_SEARCH` não retorna as colunas da tabela original quando usada com `JOIN` direto.
                                  *     -   SOLUÇÃO: A query usa uma subquery `WHERE base.id IN (SELECT id FROM VECTOR_SEARCH(...))`.
                                   *       Esta abordagem se mostrou a mais robusta.
                                    *
                                     * 3.  COTA DO VERTEX AI MATCHING ENGINE:
                                      *     -   PROBLEMA: Erros `501 Not Implemented` inexplicáveis.
                                       *     -   CAUSA: Infraestrutura legada de "Vertex AI Vector Search" (um endpoint e índice) consumindo 100% da cota.
                                        *     -   SOLUÇÃO: A infraestrutura legada foi excluída. Esta arquitetura com BigQuery não utiliza o Matching Engine.
                                         * Sempre que eu te pedir o código me de o codigo completo sem breviedades, a não ser que eu te peça expressamente. Nunca apague este comentado, ele é o santo graal do nosso código para evitar futuros problemas)
                                          * ====================================================================================
                                           */
import { setGlobalOptions } from "firebase-functions/v2";
import { onRequest } from "firebase-functions/v2/https";
import { onObjectFinalized } from "firebase-functions/v2/storage";
import * as logger from "firebase-functions/logger";
import { initializeApp } from "firebase-admin/app";
import { getAuth, DecodedIdToken } from "firebase-admin/auth";
import { getStorage } from "firebase-admin/storage";
import * as auth from "firebase-functions/v2/identity";
import { BigQuery } from "@google-cloud/bigquery";
import { CloudTasksClient } from "@google-cloud/tasks";
import { GoogleAuth } from "google-auth-library";
import { VertexAI } from "@google-cloud/vertexai";
import express from 'express';
import cors from 'cors';
import axios from "axios";
import pdf from "pdf-parse";
import { randomUUID } from "crypto";
import * as fs from "fs";
import * as path from "path";
import { Storage } from "@google-cloud/storage";

// --- INICIALIZAÇÃO E CONFIGURAÇÃO GLOBAL ---
initializeApp();

// <<<< ABORDAGEM SIMPLIFICADA E COMBINADA
const GCP_PROJECT_ID = process.env.GCP_PROJECT_ID || "uniquex-487718";
const FUNCTIONS_REGION = process.env.FUNCTIONS_REGION || "us-east1";
const EMBEDDING_REGION = process.env.EMBEDDING_REGION || "us-central1";
const EMBEDDING_MODEL = process.env.EMBEDDING_MODEL || "text-embedding-004";
const CORS_ORIGIN = process.env.CORS_ORIGIN || "https://liciai-uniquex-487718.web.app";
const BIGQUERY_LOCATION = "US";
const DATASET_STG = "stg";
const DATASET_LOG = "log";
const TABLE_ERROS = "erros_aplicacao";
const TABLE_CONTRATACOES_RAW = "pncp_contratacoes_raw";
const DATASET_CORE = "core";
const DATASET_DIM = "dim";
const VIEW_OPORTUNIDADES = "v_oportunidades_15d";
const TABLE_FUNCTION_SCORED = "fn_get_scored_opportunities";
const PNCP_API_URL = "https://pncp.gov.br/api/consulta/v1/contratacoes/publicacao";
const PNCP_API_URL_ABERTAS = "https://pncp.gov.br/api/consulta/v1/contratacoes/proposta";
const CLOUD_TASKS_QUEUE_NAME = "pncp-backfill-queue";
const ADMIN_UIDS = ["2bfsnZTOaWeiK1xaQQPljverQNn2"];
const KNOWLEDGE_BUCKET = process.env.KNOWLEDGE_BUCKET || "itensx";
const TABLE_KNOWLEDGE_VECTORS = "knowledge_vectors";

type PlanoNome = "free" | "pro" | "enterprise" | "gov";

interface ClientePlanoInfo {
        cliente_id: string;
        tenant_id: string;
        plano: PlanoNome;
        status_pagamento: string;
        limite_uf: number;
        limite_oportunidades: number;
        limite_docs: number;
        limite_produtos: number;
}

const LIMITES_PADRAO_POR_PLANO: Record<PlanoNome, Omit<ClientePlanoInfo, "cliente_id" | "tenant_id" | "plano" | "status_pagamento">> = {
        free: { limite_uf: 1, limite_oportunidades: 20, limite_docs: 3, limite_produtos: 0 },
        pro: { limite_uf: 3, limite_oportunidades: 200, limite_docs: 10, limite_produtos: 10 },
        enterprise: { limite_uf: 9999, limite_oportunidades: 999999, limite_docs: 999999, limite_produtos: 999999 },
        gov: { limite_uf: 9999, limite_oportunidades: 999999, limite_docs: 999999, limite_produtos: 999999 },
};

setGlobalOptions({ region: FUNCTIONS_REGION });
const bq = new BigQuery({ projectId: GCP_PROJECT_ID });
const googleAuth = new GoogleAuth({ scopes: "https://www.googleapis.com/auth/cloud-platform" });
const storage = new Storage({ projectId: GCP_PROJECT_ID }); // <-- ADICIONE ESTA LINHA

// --- HELPERS E UTILS ---
const sleep = (ms: number) => new Promise(res => setTimeout(res, ms));

async function executeWithRetry<T>(fn: () => Promise<T>, maxRetries = 3, initialDelayMs = 1000): Promise<T> {
        let lastError: any = null;
        for (let attempt = 0; attempt < maxRetries; attempt++) {
                try {
                        return await fn();
                } catch (err: any) {
                        lastError = err;
                        const statusCode = err?.response?.status || err?.code;
                        const isRetryable = statusCode === 429 || statusCode === "RESOURCE_EXHAUSTED";
                        if (!isRetryable || attempt === maxRetries - 1) {
                                break;
                        }
                        const backoff = Math.pow(2, attempt) * initialDelayMs;
                        const jitter = backoff * 0.2 * Math.random();
                        const delay = Math.round(backoff + jitter);
                        logger.warn(`[Retry] Status ${statusCode} detectado. Tentando novamente em ${delay}ms... (Tentativa ${attempt + 1}/${maxRetries})`);
                        await sleep(delay);
                }
        }
        throw lastError;
}

async function logErrorToBigQuery(errorData: Record<string, any>): Promise<void> {
        try {
                const nowISO = new Date().toISOString();
                const logEntry = {
                        ...errorData,
                        error_id: errorData.error_id || randomUUID(),
                        status: errorData.status || 'NOVO',
                        last_modified: nowISO,
                        timestamp: errorData.timestamp || nowISO,
                };
                await bq.dataset(DATASET_LOG).table(TABLE_ERROS).insert([logEntry]);
        } catch (error) {
                logger.error("Falha CRÍTICA ao inserir log de erro no BigQuery:", {
                        originalError: errorData,
                        loggingError: error,
                });
        }
}

// --- HELPERS DE EMBEDDING (REST) ---
async function embedTextREST(text: string): Promise<number[]> {
        const fn = async (): Promise<number[]> => {
                const authToken = (await googleAuth.getAccessToken()) || "";
                if (!authToken) throw new Error("Falha ao obter access token GCP.");
                const url = `https://${EMBEDDING_REGION}-aiplatform.googleapis.com/v1/projects/${GCP_PROJECT_ID}/locations/${EMBEDDING_REGION}/publishers/google/models/${EMBEDDING_MODEL}:predict`;
                const body = { instances: [{ content: text }] };
                logger.info("Tentando chamar a API de Embedding (:predict)", { url, model: EMBEDDING_MODEL });
                const response = await axios.post(url, body, {
                        headers: { Authorization: `Bearer ${authToken}` },
                });
                const embedding = response.data?.predictions?.[0]?.embeddings?.values;
                if (!embedding || !Array.isArray(embedding) || embedding.length === 0) {
                        logger.error("Resposta de embedding inválida da API :predict", { responseData: response.data });
                        throw new Error("Resposta de embedding inválida ou vazia da API :predict.");
                }
                return embedding;
        };
        return executeWithRetry(fn);
}

async function embedBatchREST(texts: string[]): Promise<number[][]> {
        if (!texts || texts.length === 0) {
                return [];
        }

        // AÇÃO 1: Reduzir o tamanho do lote para 2
        const BATCH_SIZE = 2;
        const allEmbeddings: number[][] = [];

        logger.info(`Iniciando embedding em lote (MODO ULTRA-SEGURO) para ${texts.length} chunks, em lotes de ${BATCH_SIZE}.`);

        for (let i = 0; i < texts.length; i += BATCH_SIZE) {
                const batchTexts = texts.slice(i, i + BATCH_SIZE);

                const fn = async (): Promise<number[][]> => {
                        const authToken = (await googleAuth.getAccessToken()) || "";
                        if (!authToken) throw new Error("Falha ao obter access token GCP.");

                        const url = `https://${EMBEDDING_REGION}-aiplatform.googleapis.com/v1/projects/${GCP_PROJECT_ID}/locations/${EMBEDDING_REGION}/publishers/google/models/${EMBEDDING_MODEL}:predict`;

                        const body = {
                                instances: batchTexts.map(text => ({ content: text }))
                        };

                        const response = await axios.post(url, body, {
                                headers: { Authorization: `Bearer ${authToken}` },
                        });

                        const predictions = response.data?.predictions;
                        if (!predictions || !Array.isArray(predictions) || predictions.length === 0) {
                                throw new Error("Resposta de embedding em lote inválida ou vazia.");
                        }

                        return predictions.map(pred => pred.embeddings.values);
                };

                try {
                        // Mantemos o retry longo, pois ele funciona.
                        const batchEmbeddings = await executeWithRetry(fn, 3, 5000);

                        allEmbeddings.push(...batchEmbeddings);
                        logger.info(`Lote ${Math.floor(i / BATCH_SIZE) + 1} processado com sucesso. Total de embeddings: ${allEmbeddings.length}`);

                        if (i + BATCH_SIZE < texts.length) {
                                // AÇÃO 2: Aumentar a pausa entre os lotes para 3 segundos
                                await sleep(3000);
                        }

                } catch (error) {
                        logger.error(`Falha CRÍTICA ao processar lote de embeddings a partir do chunk ${i}. Abortando.`, {
                                errorMessage: (error as Error).message
                        });
                        throw new Error(`Falha ao processar lote de embeddings: ${(error as Error).message}`);
                }
        }

        return allEmbeddings;
}

// --- CONFIGURAÇÃO DO SERVIDOR EXPRESS ---
const app = express();
app.use(cors({ origin: [CORS_ORIGIN, "http://localhost:5173", "http://localhost:3000", "http://127.0.0.1:5173"] }));
app.use(express.json({ limit: "10mb" }));

declare global {
        namespace Express {
                interface Request {
                        user?: DecodedIdToken;
                        uid?: string;
                        planInfo?: ClientePlanoInfo;
                }
        }
}

// --- MIDDLEWARES DE AUTENTICAÇÃO ---
const userAuthMiddleware = async (req: express.Request, res: express.Response, next: express.NextFunction) => {
        if (!req.headers.authorization || !req.headers.authorization.startsWith('Bearer ')) {
                return res.status(403).json({ message: 'Acesso negado. Token não fornecido.' });
        }
        const idToken = req.headers.authorization.split('Bearer ')[1];
        try {
                const decodedToken = await getAuth().verifyIdToken(idToken);
                req.user = decodedToken;
                req.uid = decodedToken.uid;
                return next();
        } catch (error) {
                logger.error("Falha na verificação do token de usuário", { error });
                return res.status(403).json({ message: 'Acesso negado. Token inválido.' });
        }
};

const adminAuthMiddleware = async (req: express.Request, res: express.Response, next: express.NextFunction) => {
        if (!req.headers.authorization || !req.headers.authorization.startsWith('Bearer ')) {
                return res.status(403).json({ message: 'Acesso negado. Token não fornecido.' });
        }
        const idToken = req.headers.authorization.split('Bearer ')[1];
        try {
                const decodedToken = await getAuth().verifyIdToken(idToken);
                if (!ADMIN_UIDS.includes(decodedToken.uid)) {
                        return res.status(403).json({ message: 'Acesso negado. Rota apenas para administradores.' });
                }
                req.user = decodedToken;
                req.uid = decodedToken.uid;
                return next();
        } catch (error) {
                logger.error("Falha na verificação do token de admin", { error });
                return res.status(403).json({ message: 'Acesso negado. Token inválido.' });
        }
};

let cachedClientTableName: string | null = null;
let cachedClientTableColumns: Set<string> | null = null;

const normalizePlano = (planoRaw: unknown): PlanoNome => {
        const plano = String(planoRaw || "free").toLowerCase();
        if (plano === "pro" || plano === "enterprise" || plano === "gov") return plano;
        return "free";
};

const toPositiveInt = (value: unknown, fallback: number): number => {
        const n = Number(value);
        if (Number.isFinite(n) && n >= 0) return Math.floor(n);
        return fallback;
};

const sendApiError = (
        res: express.Response,
        status: number,
        code: string,
        message: string,
        details?: Record<string, any>
) => {
        return res.status(status).json({ error: { code, message, details: details || null } });
};

async function resolveClientTableName(): Promise<string> {
        if (cachedClientTableName) return cachedClientTableName;
        const query = `
                SELECT table_name
                FROM \`${GCP_PROJECT_ID}.${DATASET_DIM}.INFORMATION_SCHEMA.TABLES\`
                WHERE table_name IN ('cliente', 'clientes')
                ORDER BY CASE WHEN table_name = 'cliente' THEN 0 ELSE 1 END
                LIMIT 1
        `;
        const [rows] = await bq.query({ query, location: BIGQUERY_LOCATION });
        if (!rows.length) {
                throw new Error("Tabela de clientes não encontrada no dataset dim (esperado: cliente ou clientes).");
        }
        cachedClientTableName = String(rows[0].table_name);
        return String(rows[0].table_name);
}

async function resolveClientTableColumns(): Promise<Set<string>> {
        if (cachedClientTableColumns) return cachedClientTableColumns;
        const tableName = await resolveClientTableName();
        const query = `
                SELECT column_name
                FROM \`${GCP_PROJECT_ID}.${DATASET_DIM}.INFORMATION_SCHEMA.COLUMNS\`
                WHERE table_name = @tableName
        `;
        const [rows] = await bq.query({ query, location: BIGQUERY_LOCATION, params: { tableName } });
        cachedClientTableColumns = new Set(rows.map((r: any) => String(r.column_name)));
        return cachedClientTableColumns;
}

function buildClientePlanoFromRow(uid: string, row: Record<string, any>): ClientePlanoInfo {
        const plano = normalizePlano(row.plano);
        const limitesPadrao = LIMITES_PADRAO_POR_PLANO[plano];
        return {
                cliente_id: uid,
                tenant_id: String(row.tenant_id || uid),
                plano,
                status_pagamento: String(row.status_pagamento || "ativo"),
                limite_uf: toPositiveInt(row.limite_uf, limitesPadrao.limite_uf),
                limite_oportunidades: toPositiveInt(row.limite_oportunidades, limitesPadrao.limite_oportunidades),
                limite_docs: toPositiveInt(row.limite_docs, limitesPadrao.limite_docs),
                limite_produtos: toPositiveInt(row.limite_produtos, limitesPadrao.limite_produtos),
        };
}

async function upsertClienteDefault(uid: string, email?: string): Promise<ClientePlanoInfo> {
        const tableName = await resolveClientTableName();
        const columns = await resolveClientTableColumns();
        const baseDefault = {
                cliente_id: uid,
                tenant_id: uid,
                email: email || "",
                nome_exibicao: (email || uid).split('@')[0] || "Novo Usuário",
                plano: "free",
                status_pagamento: "ativo",
                limite_uf: 1,
                limite_oportunidades: 20,
                limite_docs: 3,
                limite_produtos: 0,
                data_cadastro: new Date().toISOString(),
                data_ultima_modificacao: new Date().toISOString(),
        };

        const rowToInsert = Object.fromEntries(
                Object.entries(baseDefault).filter(([key]) => columns.has(key))
        );

        if (Object.keys(rowToInsert).length === 0 || !rowToInsert.cliente_id) {
                throw new Error(`Tabela ${tableName} não possui colunas mínimas para cadastro padrão.`);
        }

        await bq.dataset(DATASET_DIM).table(tableName).insert([rowToInsert]);
        return buildClientePlanoFromRow(uid, rowToInsert);
}

async function getOrCreateClientePlano(uid: string, email?: string): Promise<ClientePlanoInfo> {
        const tableName = await resolveClientTableName();
        const query = `
                SELECT TO_JSON_STRING(t) AS row_json
                FROM \`${GCP_PROJECT_ID}.${DATASET_DIM}.${tableName}\` t
                WHERE cliente_id = @cliente_id
                LIMIT 1
        `;

        const [rows] = await bq.query({
                query,
                location: BIGQUERY_LOCATION,
                params: { cliente_id: uid },
        });

        if (rows.length === 0) {
                return upsertClienteDefault(uid, email);
        }

        const parsed = JSON.parse(rows[0].row_json || "{}");
        return buildClientePlanoFromRow(uid, parsed);
}

const userPlanMiddleware = async (req: express.Request, res: express.Response, next: express.NextFunction) => {
        try {
                const uid = req.uid;
                if (!uid) {
                        return sendApiError(res, 401, "UNAUTHORIZED", "Usuário não autenticado.");
                }

                const planInfo = await getOrCreateClientePlano(uid, req.user?.email);
                if (["cancelado", "inadimplente", "bloqueado"].includes(planInfo.status_pagamento.toLowerCase())) {
                        return sendApiError(res, 403, "PLAN_INACTIVE", "Seu plano está inativo. Regularize o pagamento para continuar.", {
                                plano: planInfo.plano,
                                status_pagamento: planInfo.status_pagamento,
                        });
                }

                req.planInfo = planInfo;
                return next();
        } catch (error: any) {
                await logErrorToBigQuery({
                        funcao_ou_componente: "userPlanMiddleware",
                        cliente_id: req.uid,
                        mensagem: error.message,
                        stack_trace: error.stack,
                });
                return sendApiError(res, 500, "PLAN_LOOKUP_ERROR", "Falha ao validar plano do usuário.");
        }
};

const oportunidadesQuotaMiddleware = (req: express.Request, res: express.Response, next: express.NextFunction) => {
        const planInfo = req.planInfo;
        if (!planInfo) {
                return sendApiError(res, 500, "PLAN_CONTEXT_MISSING", "Contexto de plano não disponível.");
        }

        const ufParam = typeof req.query.uf === 'string' ? req.query.uf : '';
        const ufList = ufParam
                .split(',')
                .map((uf) => uf.trim().toUpperCase())
                .filter(Boolean);

        if (planInfo.limite_uf > 0 && ufList.length > planInfo.limite_uf) {
                return sendApiError(res, 403, "UF_LIMIT_EXCEEDED", "Seu plano não permite monitorar essa quantidade de UFs nesta consulta.", {
                        limite_uf: planInfo.limite_uf,
                        solicitado: ufList.length,
                        plano: planInfo.plano,
                });
        }

        const reqLimit = parseInt(String(req.query.limit || "21"), 10) || 21;
        const reqOffset = parseInt(String(req.query.offset || "0"), 10) || 0;

        if (planInfo.limite_oportunidades > 0) {
                const restante = planInfo.limite_oportunidades - reqOffset;
                if (restante <= 0) {
                        return sendApiError(res, 403, "QUOTA_EXCEEDED", "Limite de oportunidades do plano atingido. Faça upgrade para continuar.", {
                                recurso: "oportunidades",
                                limite: planInfo.limite_oportunidades,
                                offset: reqOffset,
                                plano: planInfo.plano,
                        });
                }

                const limitAjustado = Math.max(1, Math.min(reqLimit, restante));
                (req.query as any).limit = String(limitAjustado);
        }

        return next();
};

// --- ROTAS DO EXPRESS ---
app.get('/healthz', (_req, res) => res.status(200).send('ok'));

// Rotas Públicas
app.get('/getOportunidades', async (req, res) => {
        try {
                const { uf, q, limit: limitStr, offset: offsetStr } = req.query;
                const limit = parseInt(limitStr as string) || 21;
                const offset = parseInt(offsetStr as string) || 0;
                let query = `SELECT * FROM \`${GCP_PROJECT_ID}.${DATASET_CORE}.${VIEW_OPORTUNIDADES}\``;
                const whereClauses: string[] = [];
                const queryParams: Record<string, any> = {};
                if (uf && typeof uf === 'string' && uf.trim()) {
                        whereClauses.push("uf = @uf");
                        queryParams.uf = uf.trim().toUpperCase();
                }
                if (q && typeof q === 'string' && q.trim()) {
                        whereClauses.push("LOWER(objeto_compra) LIKE LOWER(@q)");
                        queryParams.q = `%${q.trim()}%`;
                }
                if (whereClauses.length > 0) query += ` WHERE ${whereClauses.join(" AND ")}`;
                query += " ORDER BY data_encerramento_proposta ASC LIMIT @limit OFFSET @offset";
                queryParams.limit = limit;
                queryParams.offset = offset;
                const [rows] = await bq.query({ query, location: BIGQUERY_LOCATION, params: queryParams });
                const nextOffset = rows.length === limit ? offset + limit : null;
                res.status(200).json({ items: rows, nextOffset });
        } catch (error: any) {
                await logErrorToBigQuery({ funcao_ou_componente: "getOportunidades", mensagem: error.message, stack_trace: error.stack, contexto: JSON.stringify({ reqQuery: req.query }) });
                res.status(500).send("Erro interno ao buscar oportunidades.");
        }
});

app.post('/logError', async (req, res) => {
        let clienteId = "frontend_anonimo";
        if (req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
                try {
                        const idToken = req.headers.authorization.split('Bearer ')[1];
                        const decodedToken = await getAuth().verifyIdToken(idToken, false);
                        clienteId = decodedToken.uid;
                } catch { /* Ignore token validation errors, just log anonymously */ }
        }
        try {
                const { mensagem } = req.body;
                if (!mensagem) {
                        return res.status(400).send({ message: "Campo 'mensagem' é obrigatório." });
                }
                await logErrorToBigQuery({ ...req.body, cliente_id: clienteId, severidade: "FRONTEND_ERROR" });
                return res.status(202).send({ message: "Erro registrado com sucesso." });
        } catch (error: any) {
                logger.error("ERRO CRÍTICO no endpoint /logError:", { errorMessage: error.message });
                return res.status(500).send({ message: "Erro interno no servidor de log." });
        }
});

// --- ROTAS AUTENTICADAS PARA USUÁRIOS (protegidas individualmente) ---
app.get('/getScoredOportunidades', userAuthMiddleware, userPlanMiddleware, oportunidadesQuotaMiddleware, async (req, res) => {
        try {
                const uid = req.uid!;
                const { uf, q, limit: limitStr, offset: offsetStr } = req.query;
                const limit = parseInt(limitStr as string) || 21;
                const offset = parseInt(offsetStr as string) || 0;
                let query = `SELECT * FROM \`${GCP_PROJECT_ID}.${DATASET_CORE}.${TABLE_FUNCTION_SCORED}\`(@cliente_id)`;
                const whereClauses: string[] = [];
                const queryParams: Record<string, any> = { cliente_id: uid };
                if (uf && typeof uf === 'string' && uf.trim()) {
                        whereClauses.push("uf = @uf");
                        queryParams.uf = uf.trim().toUpperCase();
                }
                if (q && typeof q === 'string' && q.trim()) {
                        whereClauses.push("LOWER(objeto_compra) LIKE LOWER(@q)");
                        queryParams.q = `%${q.trim()}%`;
                }
                if (whereClauses.length > 0) {
                        query = `SELECT * FROM (${query}) AS scored_ops WHERE ${whereClauses.join(" AND ")}`;
                }
                query += " ORDER BY score_oportunidade DESC LIMIT @limit OFFSET @offset";
                queryParams.limit = limit;
                queryParams.offset = offset;
                const [rows] = await bq.query({ query, location: BIGQUERY_LOCATION, params: queryParams });
                const nextOffset = rows.length === limit ? offset + limit : null;
                res.status(200).json({ items: rows, nextOffset, plano: req.planInfo?.plano || 'free' });
        } catch (error: any) {
                await logErrorToBigQuery({ funcao_ou_componente: "getScoredOportunidades", cliente_id: req.uid, mensagem: error.message, stack_trace: error.stack, contexto: JSON.stringify({ reqQuery: req.query }) });
                res.status(500).json({ message: 'Erro interno ao processar o ranking.' });
        }
});

app.get('/getPlanoAtual', userAuthMiddleware, userPlanMiddleware, async (req, res) => {
        const planInfo = req.planInfo!;
        res.status(200).json({
                plano: planInfo.plano,
                status_pagamento: planInfo.status_pagamento,
                limites: {
                        uf: planInfo.limite_uf,
                        oportunidades: planInfo.limite_oportunidades,
                        docs: planInfo.limite_docs,
                        produtos: planInfo.limite_produtos,
                },
                tenant_id: planInfo.tenant_id,
        });
});

app.get('/getClienteConfiguracoes', userAuthMiddleware, async (req, res) => {
        try {
                const query = `SELECT palavra_chave, peso FROM \`${GCP_PROJECT_ID}.${DATASET_DIM}.cliente_configuracoes\` WHERE cliente_id = @cliente_id ORDER BY peso DESC`;
                const [rows] = await bq.query({ query, location: BIGQUERY_LOCATION, params: { cliente_id: req.uid } });
                res.status(200).json({ palavrasChave: rows });
        } catch (error: any) {
                await logErrorToBigQuery({ funcao_ou_componente: "getClienteConfiguracoes", cliente_id: req.uid, mensagem: error.message, stack_trace: error.stack });
                res.status(500).json({ message: 'Erro interno ao buscar configurações.' });
        }
});

app.post('/addPalavraChave', userAuthMiddleware, async (req, res) => {
        try {
                const { palavraChave, peso } = req.body;
                if (!palavraChave) return res.status(400).json({ message: "Parâmetro 'palavraChave' é obrigatório." });
                const finalPeso = typeof peso === 'number' && !isNaN(peso) ? peso : 1;
                const query = `MERGE \`${GCP_PROJECT_ID}.${DATASET_DIM}.cliente_configuracoes\` T
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 USING (SELECT @clienteId AS cliente_id, @palavraChave AS palavra_chave) S
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           ON T.cliente_id = S.cliente_id AND T.palavra_chave = S.palavra_chave
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     WHEN MATCHED THEN UPDATE SET peso = @finalPeso, data_ultima_modificacao = CURRENT_TIMESTAMP()
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               WHEN NOT MATCHED THEN INSERT (cliente_id, palavra_chave, peso, data_criacao, data_ultima_modificacao)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         VALUES(@clienteId, @palavraChave, @finalPeso, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP())`;
                await bq.query({ query, params: { clienteId: req.uid, palavraChave: palavraChave.toLowerCase(), finalPeso } });
                return res.status(200).json({ success: true });
        } catch (error: any) {
                await logErrorToBigQuery({ funcao_ou_componente: "addPalavraChave", cliente_id: req.uid, mensagem: error.message, stack_trace: error.stack, contexto: JSON.stringify(req.body) });
                return res.status(500).json({ message: 'Erro interno ao salvar palavra-chave.' });
        }
});

app.post('/removePalavraChave', userAuthMiddleware, async (req, res) => {
        try {
                const { palavraChave } = req.body;
                if (!palavraChave) return res.status(400).json({ message: "Parâmetro 'palavraChave' é obrigatório." });
                const query = `DELETE FROM \`${GCP_PROJECT_ID}.${DATASET_DIM}.cliente_configuracoes\` WHERE cliente_id = @clienteId AND palavra_chave = @palavraChave`;
                await bq.query({ query, params: { clienteId: req.uid, palavraChave: palavraChave.toLowerCase() } });
                return res.status(200).json({ success: true });
        } catch (error: any) {
                await logErrorToBigQuery({ funcao_ou_componente: "removePalavraChave", cliente_id: req.uid, mensagem: error.message, stack_trace: error.stack, contexto: JSON.stringify(req.body) });
                return res.status(500).json({ message: 'Erro interno ao remover palavra-chave.' });
        }
});

app.get('/getDetalhesOportunidade', userAuthMiddleware, userPlanMiddleware, async (req, res) => {
        try {
                const { id } = req.query;
                if (!id) return res.status(400).json({ message: "ID da oportunidade é obrigatório." });
                const query = `SELECT payload FROM \`${GCP_PROJECT_ID}.${DATASET_STG}.${TABLE_CONTRATACOES_RAW}\` WHERE JSON_EXTRACT_SCALAR(payload, '$.numeroControlePNCP') = @id LIMIT 1`;
                const [rows] = await bq.query({ query, params: { id } });
                if (rows.length === 0) return res.status(404).json({ message: "Oportunidade não encontrada." });
                return res.status(200).json(JSON.parse(rows[0].payload));
        } catch (error: any) {
                await logErrorToBigQuery({ funcao_ou_componente: "getDetalhesOportunidade", cliente_id: req.uid, mensagem: error.message, stack_trace: error.stack, contexto: JSON.stringify(req.query) });
                return res.status(500).json({ message: 'Erro interno ao buscar detalhes.' });
        }
});

app.post('/iniciarBackfill', userAuthMiddleware, async (req, res) => {
        try {
                const { inicio, fim } = req.body;
                const dataInicioStr = (inicio as string) || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
                const dataFimStr = (fim as string) || new Date().toISOString().slice(0, 10);
                const ufs = ['AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MT', 'MS', 'MG', 'PA', 'PB', 'PR', 'PE', 'PI', 'RJ', 'RN', 'RS', 'RO', 'RR', 'SC', 'SP', 'SE', 'TO'];
                const tasksClient = new CloudTasksClient();
                const queuePath = tasksClient.queuePath(GCP_PROJECT_ID, FUNCTIONS_REGION, CLOUD_TASKS_QUEUE_NAME);
                const workerUrl = `https://${FUNCTIONS_REGION}-${GCP_PROJECT_ID}.cloudfunctions.net/coletarPncp`;
                const taskPromises: Promise<any>[] = [];
                let currentDate = new Date(dataInicioStr);
                const endDate = new Date(dataFimStr);
                while (currentDate <= endDate) {
                        const dateString = currentDate.toISOString().slice(0, 10);
                        for (const uf of ufs) {
                                const task = {
                                        httpRequest: {
                                                httpMethod: 'GET' as const,
                                                url: `${workerUrl}?uf=${uf}&data=${dateString}`,
                                        },
                                };
                                taskPromises.push(tasksClient.createTask({ parent: queuePath, task }));
                        }
                        currentDate.setDate(currentDate.getDate() + 1);
                }
                await Promise.all(taskPromises);
                res.status(200).send(`${taskPromises.length} tarefas de coleta enfileiradas com sucesso.`);
        } catch (error: any) {
                await logErrorToBigQuery({ funcao_ou_componente: "iniciarBackfill", cliente_id: req.uid, mensagem: error.message, stack_trace: error.stack, contexto: JSON.stringify(req.body) });
                res.status(500).send("Falha ao enfileirar tarefas de backfill.");
        }
});

app.post('/generateUploadUrl', adminAuthMiddleware, async (req, res) => {
        try {
                const { fileName, contentType } = req.body;
                if (!fileName || !contentType) {
                        return res.status(400).json({ message: 'fileName e contentType são obrigatórios.' });
                }

                const uid = req.uid!; // uid vem do adminAuthMiddleware

                // Organiza os arquivos em uma pasta "uploads" dentro do bucket.
                // O nome final será algo como: uploads/2bfsnZTOaW.../167...-meu-documento.pdf
                const filePath = `uploads/${uid}/${Date.now()}-${fileName}`;

                const options = {
                        version: 'v4' as const,
                        action: 'write' as const,
                        expires: Date.now() + 15 * 60 * 1000, // URL expira em 15 minutos
                        contentType: contentType,
                };

                // Gera a URL assinada usando a constante KNOWLEDGE_BUCKET
                const [url] = await storage
                        .bucket(KNOWLEDGE_BUCKET)
                        .file(filePath)
                        .getSignedUrl(options);

                return res.status(200).json({ signedUrl: url });

        } catch (error: any) {
                logger.error("Erro ao gerar a URL assinada de upload", { error: error.message, stack: error.stack });
                await logErrorToBigQuery({
                        funcao_ou_componente: "generateUploadUrl",
                        cliente_id: req.uid,
                        mensagem: error.message,
                        stack_trace: error.stack,
                        contexto: JSON.stringify(req.body)
                });
                return res.status(500).json({ message: 'Erro interno ao gerar URL de upload.' });
        }
});

// --- ROTAS DE ADMIN (protegidas individualmente com adminAuthMiddleware) ---
app.post("/assistenteSprint", adminAuthMiddleware, async (req, res) => {
        try {
                let { userPrompt, projectContext } = req.body; // Alterado para 'let' para permitir modificação

                if (!userPrompt || userPrompt.trim() === '') {
                        return res.status(400).json({ message: "O 'userPrompt' não pode ser vazio." });
                }

                // ===== INÍCIO DA LÓGICA DE CONTEXTO DINÂMICO FULL-STACK =====
                try {
                        // Caminho para o index.ts (backend)
                        // __dirname aponta para '.../functions/lib', então voltamos um para 'functions' e entramos em 'src'
                        const backendCodePath = path.join(__dirname, '..', 'src', 'index.ts');
                        const backendCode = fs.readFileSync(backendCodePath, 'utf-8');

                        // Caminho para o index.html (frontend)
                        // A partir de '.../functions/lib', voltamos dois níveis para a raiz do projeto e entramos em 'public'
                        const frontendCodePath = path.join(__dirname, '..', '..', 'public', 'index.html');
                        const frontendCode = fs.readFileSync(frontendCodePath, 'utf-8');

                        // Injetamos AMBOS os arquivos no projectContext
                        projectContext = {
                                ...(projectContext || {}),
                                current_code_files: [
                                        {
                                                file_path: "functions/src/index.ts",
                                                content: backendCode
                                        },
                                        {
                                                file_path: "public/index.html",
                                                content: frontendCode
                                        }
                                ]
                        };
                        logger.info("Códigos-fonte do backend (index.ts) e frontend (index.html) carregados dinamicamente para o contexto.");

                } catch (codeError: any) {
                        logger.error("Falha ao carregar os códigos-fonte dinamicamente.", { error: codeError.message });
                        // A execução continua mesmo se a leitura dos arquivos falhar.
                }
                // ===== FIM DA LÓGICA DE CONTEXTO DINÂMICO =====


                // ===== CARREGAR O DNA DO PROJETO =====
                let projectDnaContext = "O DNA do projeto não foi encontrado ou está vazio.";
                try {
                        const dnaQuery = `SELECT content FROM \`${GCP_PROJECT_ID}.${DATASET_CORE}.project_dna\` WHERE id = 'main' LIMIT 1`;
                        const [dnaRows] = await bq.query({ query: dnaQuery });
                        if (dnaRows.length > 0 && dnaRows[0].content) {
                                projectDnaContext = dnaRows[0].content;
                                logger.info("DNA do Projeto carregado com sucesso para o contexto da IA.");
                        }
                } catch (dnaError: any) {
                        logger.error("Falha ao carregar o DNA do projeto para o contexto da IA", { error: dnaError.message });
                        projectDnaContext = "Ocorreu um erro ao tentar carregar o DNA do projeto.";
                }
                // ===== FIM DO CARREGAMENTO DO DNA =====


                // Lógica de busca vetorial (inalterada)
                let knowledgeContext = "Nenhuma informação relevante foi encontrada na base de conhecimento.";
                try {
                        const queryEmbedding = await embedTextREST(userPrompt);
                        const vectorSearchQuery = `SELECT content FROM \`${GCP_PROJECT_ID}.${DATASET_CORE}.${TABLE_KNOWLEDGE_VECTORS}\` ORDER BY COSINE_DISTANCE(embedding, [${queryEmbedding.join(',')}]) ASC LIMIT 5`;

                        logger.info("Executando Query de Busca Vetorial (ORDER BY COSINE_DISTANCE)...");
                        const [contentRows] = await bq.query({ query: vectorSearchQuery, location: BIGQUERY_LOCATION });

                        if (contentRows && contentRows.length > 0) {
                                knowledgeContext = "Foram encontrados os seguintes trechos relevantes na base de conhecimento:\n" + contentRows.map((row: any) => `- ${row.content}`).join("\n");
                                logger.info("Contexto relevante encontrado via COSINE_DISTANCE.");
                        }
                } catch (searchError: any) {
                        logger.error("--- ERRO NA BUSCA VETORIAL (BIGQUERY) ---", { errorMessage: searchError.message, bigQueryErrors: searchError.errors });
                        knowledgeContext = "Ocorreu um erro ao consultar a base de conhecimento.";
                }

                // --- ETAPA FINAL: CHAMADA SEGURA PARA A VERTEX AI ---
                let responseText: string | undefined;
                try {
                        logger.info("Preparando para chamar a IA Generativa (Gemini)...");
                        const generativeModel = new VertexAI({ project: GCP_PROJECT_ID, location: FUNCTIONS_REGION })
                                .getGenerativeModel({
                                        model: "gemini-2.5-pro",
                                        generationConfig: { responseMimeType: "application/json" }
                                });

                        const prompt = `
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         Você é um Arquiteto de Software Sênior e programador full-stack especialista em Google Cloud, TypeScript, e BigQuery.
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         Sua tarefa é analisar uma solicitação e gerar um plano de ação claro e o código necessário.

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         **SUA DIRETRIZ MAIS IMPORTANTE E INEGOCIÁVEL:** Você deve obedecer a TODAS as regras, padrões e "Lições Críticas Aprendidas" documentadas no 'DNA DO PROJETO' abaixo. O DNA DO PROJETO é a sua fonte de verdade absoluta e prevalece sobre qualquer outro conhecimento que você tenha. Se uma solicitação do desenvolvedor violar uma regra do DNA, você deve RECUSAR a solicitação e justificar sua recusa citando a regra específica do DNA.

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         --- DNA DO PROJETO ---
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         ${projectDnaContext}
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         --- FIM DO DNA DO PROJETO ---

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         Contextos adicionais (subordinados ao DNA):
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         1. CONTEXTO INTERNO (Código-fonte atual e outros dados): 
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            ${projectContext ? JSON.stringify(projectContext, null, 2) : "Não fornecido."}

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            2. CONTEXTO EXTERNO (Busca Vetorial em documentos):
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ${knowledgeContext}

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               SOLICITAÇÃO DO DESENVOLVEDOR: "${userPrompt}"

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               Com base em TODOS os contextos, tratando o DNA DO PROJETO como sua regra máxima e usando o CONTEXTO INTERNO para entender o código existente (backend em 'functions/src/index.ts' e frontend em 'public/index.html'), gere uma resposta no formato JSON.
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               Estrutura de resposta JSON:
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 "explicacao": "Uma explicação clara. Se recusar a tarefa, explique o porquê aqui, citando o DNA.",
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   "alteracoes": [
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             "arquivo": "O caminho completo do arquivo a ser modificado (ex: 'public/index.html' ou 'functions/src/index.ts').",
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   "acao": "A ação a ser tomada (ex: 'ADICIONAR ROTA', 'ADICIONAR LÓGICA JAVASCRIPT').",
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         "codigo": "O trecho de código completo e pronto para ser copiado e colado."
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ]
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               Retorne APENAS o objeto JSON válido.
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           `;

                        logger.info("Enviando prompt para o Gemini...");
                        const result = await generativeModel.generateContent(prompt);
                        responseText = result.response.candidates?.[0]?.content?.parts?.[0]?.text;
                        logger.info("Recebida resposta do Gemini com sucesso.");

                } catch (geminiError: any) {
                        logger.error("--- ERRO CRÍTICO AO CHAMAR A API VERTEX AI (GEMINI) ---", {
                                errorMessage: geminiError.message,
                                errorDetails: (geminiError as any).details,
                                stack: geminiError.stack,
                        });
                        throw new Error("Falha na comunicação com a API de IA Generativa.");
                }

                if (!responseText) {
                        throw new Error("A IA (Gemini) retornou uma resposta vazia.");
                }

                try {
                        return res.status(200).json(JSON.parse(responseText));
                } catch (e: any) {
                        logger.warn("Falha no parse inicial do JSON da IA. Tentando sanitizar a string...", { errorMessage: e.message, responseText: responseText });
                        const sanitizedResponseText = responseText.replace(/\\(?!["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, '\\\\');
                        try {
                                const parsedJson = JSON.parse(sanitizedResponseText);
                                logger.info("Parse do JSON bem-sucedido após sanitização.");
                                return res.status(200).json(parsedJson);
                        } catch (finalError: any) {
                                logger.error("ERRO CRÍTICO: Não foi possível fazer o parse do JSON da IA, mesmo após sanitização.", { originalResponse: responseText, sanitizedResponse: sanitizedResponseText, finalErrorMessage: finalError.message });
                                const fallbackResponse = {
                                        explicacao: "A IA gerou uma resposta, mas em um formato de texto que não pôde ser convertido para JSON. Aqui está a resposta bruta:\n\n" + responseText,
                                        alteracoes: []
                                };
                                return res.status(200).json(fallbackResponse);
                        }
                }

        } catch (error: any) {
                logger.error("Erro CRÍTICO no fluxo do assistenteSprint", { message: error.message, stack: error.stack });
                await logErrorToBigQuery({ funcao_ou_componente: "assistenteSprint", cliente_id: req.uid, mensagem: `Falha no fluxo do assistente: ${error.message}`, stack_trace: error.stack });
                return res.status(500).json({ message: "Erro ao processar a solicitação do assistente de IA." });
        }
});

app.get('/getProjectStructure', adminAuthMiddleware, async (_req, res) => {
        try {
                const jsonPath = path.join(__dirname, "project-structure.json");
                if (fs.existsSync(jsonPath)) {
                        const raw = fs.readFileSync(jsonPath, "utf8");
                        return res.status(200).json(JSON.parse(raw));
                }
                return res.status(404).json({ message: "project-structure.json não encontrado. Execute o build localmente." });
        } catch (error: any) {
                await logErrorToBigQuery({ funcao_ou_componente: "getProjectStructure", cliente_id: "admin", mensagem: error.message, stack_trace: error.stack });
                return res.status(500).json({ message: "Erro ao ler a estrutura do projeto." });
        }
});

app.get('/getProjectSchema', adminAuthMiddleware, async (_req, res) => {
        try {
                const datasetsToScan = [DATASET_CORE, DATASET_DIM, DATASET_LOG, DATASET_STG];
                const schemaPromises = datasetsToScan.map(async (datasetId) => {
                        const [tables] = await bq.dataset(datasetId).getTables();
                        const tablePromises = tables.map(async (table) => {
                                const [metadata] = await table.getMetadata();
                                return {
                                        id: table.id,
                                        type: metadata.type,
                                        schema: metadata.schema.fields.map((f: any) => ({ name: f.name, type: f.type, mode: f.mode || 'NULLABLE' })),
                                };
                        });
                        return { id: datasetId, tables: await Promise.all(tablePromises) };
                });
                res.status(200).json({ bigquerySchema: await Promise.all(schemaPromises) });
        } catch (error: any) {
                await logErrorToBigQuery({ funcao_ou_componente: "getProjectSchema", cliente_id: "admin", mensagem: error.message, stack_trace: error.stack });
                res.status(500).json({ message: "Erro ao gerar o schema do projeto." });
        }
});

app.get('/getErros', adminAuthMiddleware, async (req, res) => {
        try {
                const limit = parseInt(req.query.limit as string) || 50;
                const offset = parseInt(req.query.offset as string) || 0;
                const status = (req.query.status as string | undefined)?.toUpperCase();

                const params: Record<string, any> = { limit, offset };

                let query = `
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               WITH t AS (
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               SELECT *, ROW_NUMBER() OVER(PARTITION BY error_id ORDER BY COALESCE(last_modified, timestamp) DESC) as rn
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               FROM \`${GCP_PROJECT_ID}.${DATASET_LOG}.${TABLE_ERROS}\`
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               WHERE error_id IS NOT NULL
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           )
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       SELECT * EXCEPT(rn)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   FROM t
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               WHERE rn = 1 AND (status IS NULL OR status != 'DELETADO')
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       `;

                if (status && status !== 'TODOS') {
                        query += " AND status = @status";
                        params.status = status;
                }

                query += " ORDER BY COALESCE(last_modified, timestamp) DESC LIMIT @limit OFFSET @offset";

                const [rows] = await bq.query({ query, params, location: BIGQUERY_LOCATION });
                res.status(200).json({ items: rows, nextOffset: rows.length === limit ? offset + limit : null });
        } catch (error: any) {
                await logErrorToBigQuery({ funcao_ou_componente: "getErros", cliente_id: req.uid, mensagem: error.message, stack_trace: error.stack });
                res.status(500).json({ message: "Erro ao buscar logs de erro." });
        }
});

app.post('/gerarErroDeTeste', adminAuthMiddleware, async (req, res) => {
        try {
                await logErrorToBigQuery({
                        severidade: "TEST",
                        ambiente: "backend",
                        funcao_ou_componente: "gerarErroDeTeste",
                        cliente_id: req.uid,
                        mensagem: "Este é um erro de teste gerado intencionalmente.",
                        stack_trace: "at Object.gerarErro (fake_file.js:10:15)",
                        contexto: JSON.stringify({ info: "Acionado pelo admin." }),
                });
                res.status(200).json({ message: "Erro de teste gerado com sucesso." });
        } catch (error: any) {
                logger.error("Falha ao gerar erro de teste", { error: error.message });
                res.status(500).json({ message: "Falha interna ao gerar o erro de teste." });
        }
});

app.post('/updateErrorStatus', adminAuthMiddleware, async (req, res) => {
        try {
                const { errorId, newStatus } = req.body;
                if (!errorId || !newStatus) return res.status(400).json({ message: "errorId e newStatus são obrigatórios." });

                const newRow = { error_id: errorId, status: newStatus, last_modified: new Date().toISOString() };
                await bq.dataset(DATASET_LOG).table(TABLE_ERROS).insert([newRow]);
                return res.status(200).json({ success: true, message: `Status do erro ${errorId} atualizado para ${newStatus}.` });
        } catch (error: any) {
                await logErrorToBigQuery({ funcao_ou_componente: "updateErrorStatus", cliente_id: req.uid, mensagem: error.message, stack_trace: error.stack, contexto: JSON.stringify(req.body) });
                return res.status(500).json({ message: 'Erro ao atualizar status.' });
        }
});

app.post('/deleteError', adminAuthMiddleware, async (req, res) => {
        try {
                const { errorId } = req.body;
                if (!errorId) return res.status(400).json({ message: "errorId é obrigatório." });

                const row = { error_id: errorId, status: "DELETADO", last_modified: new Date().toISOString() };
                await bq.dataset(DATASET_LOG).table(TABLE_ERROS).insert([row]);

                return res.status(200).json({ success: true, message: `Erro ${errorId} marcado como DELETADO.` });
        } catch (error: any) {
                await logErrorToBigQuery({ funcao_ou_componente: "deleteError", cliente_id: req.uid, mensagem: error.message, stack_trace: error.stack, contexto: JSON.stringify(req.body) });
                return res.status(500).json({ message: 'Erro ao marcar erro como deletado.' });
        }
});

app.post('/updateErrorStatusBulk', adminAuthMiddleware, async (req, res) => {
        try {
                const { errorIds, newStatus } = req.body;
                if (!Array.isArray(errorIds) || errorIds.length === 0 || !newStatus) {
                        return res.status(400).json({ message: "errorIds (array) e newStatus são obrigatórios." });
                }
                const now = new Date().toISOString();
                const rows = errorIds.map((id: string) => ({ error_id: id, status: newStatus, last_modified: now }));
                await bq.dataset(DATASET_LOG).table(TABLE_ERROS).insert(rows);
                return res.status(200).json({ success: true, message: `${errorIds.length} erros marcados como ${newStatus}.` });
        } catch (error: any) {
                await logErrorToBigQuery({ funcao_ou_componente: "updateErrorStatusBulk", cliente_id: req.uid, mensagem: error.message, stack_trace: error.stack, contexto: JSON.stringify(req.body) });
                return res.status(500).json({ message: 'Erro ao atualizar status em massa.' });
        }
});

app.post('/deleteErrorBulk', adminAuthMiddleware, async (req, res) => {
        try {
                const { errorIds } = req.body;
                if (!Array.isArray(errorIds) || errorIds.length === 0) {
                        return res.status(400).json({ message: "errorIds (array) é obrigatório." });
                }

                const now = new Date().toISOString();
                const rows = errorIds.map((id: string) => ({ error_id: id, status: "DELETADO", last_modified: now }));
                await bq.dataset(DATASET_LOG).table(TABLE_ERROS).insert(rows);

                return res.status(200).json({ success: true, message: `${errorIds.length} erros marcados como DELETADO.` });
        } catch (error: any) {
                await logErrorToBigQuery({ funcao_ou_componente: "deleteErrorBulk", cliente_id: req.uid, mensagem: error.message, stack_trace: error.stack, contexto: JSON.stringify(req.body) });
                return res.status(500).json({ message: 'Erro ao marcar erros como deletados.' });
        }
});

app.post('/analisarEstruturaComIA', adminAuthMiddleware, async (req, res) => {
        try {
                const { structure } = req.body;
                if (!structure) return res.status(400).json({ message: "Objeto 'structure' é obrigatório." });

                const vertex_ai = new VertexAI({ project: GCP_PROJECT_ID, location: FUNCTIONS_REGION });
                const model = vertex_ai.getGenerativeModel({
                        model: "gemini-2.5-pro",
                        generationConfig: { responseMimeType: "application/json", temperature: 0.2 },
                });

                const prompt = `Analise a estrutura de projeto JSON a seguir e retorne um objeto JSON com as chaves "summary", "keyPoints", e "nextSteps".\n\n${JSON.stringify(structure, null, 2)}`;

                const result: any = await executeWithRetry(() => model.generateContent({ contents: [{ role: "user", parts: [{ text: prompt }] }] }));

                const responseText = result.response?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
                if (!responseText) throw new Error("A IA retornou uma resposta vazia.");

                return res.status(200).json(JSON.parse(responseText));
        } catch (error: any) {
                await logErrorToBigQuery({ funcao_ou_componente: "analisarEstruturaComIA", cliente_id: req.uid, mensagem: error.message, stack_trace: error.stack });
                return res.status(500).json({ message: "A IA não conseguiu analisar a estrutura." });
        }
});

app.post('/analisarErroComIA', adminAuthMiddleware, async (req, res) => {
        try {
                const { error: errorObj } = req.body;
                if (!errorObj || !errorObj.error_id) return res.status(400).json({ message: "Objeto de erro inválido." });

                const vertex_ai = new VertexAI({ project: GCP_PROJECT_ID, location: FUNCTIONS_REGION });
                const model = vertex_ai.getGenerativeModel({
                        model: "gemini-2.5-pro",
                        generationConfig: { responseMimeType: "application/json", temperature: 0.2 },
                });

                const prompt = `Analise o erro a seguir e retorne um JSON com "explicacao" e "sugestao_codigo".\n\n${JSON.stringify(errorObj)}`;
                const result: any = await executeWithRetry(() => model.generateContent({ contents: [{ role: "user", parts: [{ text: prompt }] }] }));

                const responseText = result.response?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
                if (!responseText) throw new Error("A IA retornou uma resposta vazia.");
                const analysis = JSON.parse(responseText);

                await bq.dataset(DATASET_LOG).table(TABLE_ERROS).insert([{ error_id: errorObj.error_id, analise_ia: JSON.stringify(analysis), last_modified: new Date().toISOString() }]);

                return res.status(200).json(analysis);
        } catch (error: any) {
                await logErrorToBigQuery({ funcao_ou_componente: "analisarErroComIA", cliente_id: req.uid, mensagem: error.message, stack_trace: error.stack, contexto: JSON.stringify(req.body) });
                return res.status(500).json({ message: "A IA não conseguiu analisar o erro." });
        }
});

// --- ROTAS DE ADMIN PARA O DNA DO PROJETO ---

// Rota para buscar o conteúdo atual do DNA
app.get('/getProjectDna', adminAuthMiddleware, async (_req, res) => {
        try {
                const query = `SELECT content, last_modified FROM \`${GCP_PROJECT_ID}.${DATASET_CORE}.project_dna\` WHERE id = 'main' LIMIT 1`;
                const [rows] = await bq.query({ query });

                if (rows.length === 0) {
                        return res.status(404).json({ message: "Documento DNA do projeto não encontrado." });
                }
                return res.status(200).json(rows[0]);
        } catch (error: any) {
                await logErrorToBigQuery({ funcao_ou_componente: "getProjectDna", mensagem: error.message, stack_trace: error.stack });
                return res.status(500).json({ message: 'Erro ao buscar o DNA do projeto.' });
        }
});

// Rota para salvar (atualizar) o conteúdo do DNA
app.post('/updateProjectDna', adminAuthMiddleware, async (req, res) => {
        try {
                const { content } = req.body;
                if (typeof content !== 'string') {
                        return res.status(400).json({ message: "'content' é obrigatório e deve ser uma string." });
                }

                const query = `
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           UPDATE \`sharp-footing-475513-c7.core.project_dna\`
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       SET content = @content, last_modified = CURRENT_TIMESTAMP()
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   WHERE id = 'main'
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           `;
                await bq.query({ query, params: { content } });
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        return res.status(200).json({ success: true, message: "DNA do projeto atualizado com sucesso." });
        } catch (error: any) {
                await logErrorToBigQuery({ funcao_ou_componente: "updateProjectDna", mensagem: error.message, stack_trace: error.stack });
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        return res.status(500).json({ message: 'Erro ao salvar o DNA do projeto.' });
        }
});

// --- ROTEADOR PRINCIPAL E EXPORTAÇÃO DA API ---
const root = express();
root.use('/api', app);
export const api = onRequest(
        {
                memory: "2GiB", // <-- AUMENTA A MEMÓRIA E A CPU
                cpu: 1, // Opcional, mas explícito para Cloud Functions v2
                region: FUNCTIONS_REGION,
                invoker: "public",
                timeoutSeconds: 300,
                minInstances: 0
        },
        root
);


// --- DEMAIS TRIGGERS ---
export const processarDocumentoConhecimento = onObjectFinalized(
        {
                bucket: KNOWLEDGE_BUCKET,
                memory: "1GiB",
                timeoutSeconds: 540 // <-- ADICIONE ISSO (540 segundos = 9 minutos)
        },
        async (event) => {
                const { bucket, name } = event.data;
                if (!name) return;
                logger.info(`Arquivo '${name}' detectado. Iniciando processamento para BigQuery.`);

                try {
                        const fileBuffer = (await getStorage().bucket(bucket).file(name).download())[0];
                        let textContent = "";

                        if (name.toLowerCase().endsWith('.pdf')) {
                                const data = await pdf(fileBuffer);
                                textContent = data.text;
                        } else {
                                textContent = fileBuffer.toString('utf-8');
                        }

                        if (!textContent.trim()) {
                                logger.warn(`Nenhum texto extraído do arquivo: ${name}`);
                                return;
                        }

                        const chunks = textContent.match(/[\s\S]{1,1000}/g) || [];
                        if (chunks.length === 0) {
                                logger.warn(`O arquivo ${name} não gerou chunks de texto.`);
                                return;
                        }
                        logger.info(`Arquivo dividido em ${chunks.length} chunks.`);

                        const embeddings = await embedBatchREST(chunks);
                        logger.info(`${embeddings.length} embeddings gerados via REST.`);

                        const rowsToInsert = chunks.map((chunk, i) => ({
                                id: `${name.replace(/[^a-zA-Z0-9]/g, "_")}_${i}`,
                                content: chunk,
                                embedding: embeddings[i],
                                source_file: name,
                                created_at: new Date().toISOString()
                        }));

                        await bq.dataset(DATASET_CORE).table(TABLE_KNOWLEDGE_VECTORS).insert(rowsToInsert);
                        logger.info(`Sucesso! ${rowsToInsert.length} vetores do arquivo '${name}' foram inseridos na tabela ${TABLE_KNOWLEDGE_VECTORS}.`);

                } catch (error: any) {
                        await logErrorToBigQuery({
                                funcao_ou_componente: "processarDocumentoConhecimento",
                                mensagem: `Falha ao salvar vetores no BigQuery: ${error.message}`,
                                stack_trace: error.stack,
                                contexto: JSON.stringify({ bucket, file: name, bqErrors: error.errors })
                        });
                        logger.error(`Falha CRÍTICA ao processar o arquivo '${name}' para o BigQuery`, { message: error.message, stack: error.stack });
                }
        });

export const criarRegistroClienteNovo = auth.beforeUserCreated(async (event) => {
        const user = event.data;
        if (!user?.uid || !user.email) {
                logger.error("Tentativa de criação de usuário com UID ou Email ausentes.", { eventData: user });
                throw new Error("UID ou Email ausentes no evento de criação de usuário.");
        }
        const { uid, email, displayName } = user;
        const cliente = {
                cliente_id: uid,
                tenant_id: uid,
                email: email,
                nome_exibicao: displayName || email.split('@')[0] || 'Novo Usuário',
                plano: "free",
                status_pagamento: "ativo",
                limite_uf: 1,
                limite_oportunidades: 20,
                limite_docs: 3,
                limite_produtos: 0,
                data_cadastro: new Date().toISOString(),
                data_ultima_modificacao: new Date().toISOString()
        };
        try {
                const tableName = await resolveClientTableName();
                const columns = await resolveClientTableColumns();
                const rowToInsert = Object.fromEntries(
                        Object.entries(cliente).filter(([key]) => columns.has(key))
                );
                await bq.dataset(DATASET_DIM).table(tableName).insert([rowToInsert]);
                logger.info(`Cliente ${uid} inserido com sucesso no BigQuery.`);
        } catch (error: any) {
                await logErrorToBigQuery({
                        funcao_ou_componente: "criarRegistroClienteNovo",
                        cliente_id: uid,
                        mensagem: `Falha ao inserir novo cliente no BigQuery: ${error.message}`,
                        stack_trace: error.stack,
                        contexto: JSON.stringify({ userEventData: event.data })
                });
                logger.error(`Falha CRÍTICA ao criar registro no BQ para o cliente ${uid}`, { error });
                throw new Error("Não foi possível finalizar seu cadastro. A equipe foi notificada.");
        }
});

const coletar = async (url: string, uf: string, dataColeta: string | null, res: express.Response) => {
        try {
                let pagina = 1, totalInserido = 0;
                const tamanhoPagina = 50;
                while (true) {
                        const params: any = { uf, pagina, tamanhoPagina, codigoModalidadeContratacao: 6 };
                        if (dataColeta) {
                                params.dataInicial = dataColeta;
                                params.dataFinal = dataColeta;
                        } else {
                                params.dataFinal = new Date().toISOString().slice(0, 10).replace(/-/g, "");
                        }
                        const response = await axios.get(url, { params, timeout: 60000 });
                        const contratacoes = response.data?.data || [];
                        if (contratacoes.length > 0) {
                                const rows = contratacoes.map((item: any) => ({ ingest_time: new Date(), payload: JSON.stringify(item) }));
                                await bq.dataset(DATASET_STG).table(TABLE_CONTRATACOES_RAW).insert(rows);
                                totalInserido += rows.length;
                        }
                        if (contratacoes.length < tamanhoPagina) break;
                        pagina++;
                }
                const msg = `Coleta concluída para ${uf}. Total: ${totalInserido}.`;
                logger.info(msg);
                res.status(200).send(msg);
        } catch (error: any) {
                const errorContext = { uf, dataColeta, url, axiosError: axios.isAxiosError(error) ? { status: error.response?.status, data: error.response?.data } : null };
                await logErrorToBigQuery({ funcao_ou_componente: "coletar", mensagem: error.message, stack_trace: error.stack, contexto: JSON.stringify(errorContext) });
                logger.error(`Erro na coleta para ${uf}`, errorContext);
                res.status(500).send(`Erro ao coletar dados para ${uf}.`);
        }
}

export const coletarPncp = onRequest({ timeoutSeconds: 540, memory: "1GiB" }, async (req, res) => {
        const uf = (req.query.uf as string)?.toUpperCase() || "MT";
        let dataColeta: string;
        if (req.query.data && /^\d{4}-\d{2}-\d{2}$/.test(req.query.data as string)) {
                dataColeta = (req.query.data as string).replace(/-/g, "");
        } else {
                const yesterday = new Date();
                yesterday.setDate(yesterday.getDate() - 1);
                dataColeta = yesterday.toISOString().slice(0, 10).replace(/-/g, "");
        }
        await coletar(PNCP_API_URL, uf, dataColeta, res);
});

export const coletarLicitacoesAbertas = onRequest({ timeoutSeconds: 540, memory: "1GiB" }, async (req, res) => {
        const uf = (req.query.uf as string)?.toUpperCase() || "MT";
        await coletar(PNCP_API_URL_ABERTAS, uf, null, res);
});