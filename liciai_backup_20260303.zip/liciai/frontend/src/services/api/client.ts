// Este arquivo é legado — use src/lib/api.ts que usa URL relativa via Firebase Hosting proxy.
const API_BASE_URL = import.meta.env.VITE_API_BASE || "/api";

export async function apiGet<T>(path: string, token?: string): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    headers: token ? { Authorization: `Bearer ${token}` } : undefined,
  });

  if (!response.ok) {
    throw new Error(`API error ${response.status}`);
  }

  return response.json() as Promise<T>;
}
