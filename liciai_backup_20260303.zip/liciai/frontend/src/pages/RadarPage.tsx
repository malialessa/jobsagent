import { useState, useMemo } from "react";
import { RefreshCw, ChevronRight, AlertCircle, TrendingUp } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useOportunidades } from "@/hooks/useOportunidades";
import { usePlano } from "@/hooks/usePlano";
import type { Oportunidade } from "@/lib/api";
import { cn } from "@/lib/utils";

const UFS = ["", "SP", "MG", "RJ", "PR", "RS", "BA", "GO", "PE", "CE", "MT", "MS", "SC", "DF"];

function diasRestantes(iso: string): number {
  const encerra = new Date(iso);
  const hoje = new Date();
  return Math.ceil((encerra.getTime() - hoje.getTime()) / 86_400_000);
}

function formatDate(iso: string): string {
  try {
    return new Intl.DateTimeFormat("pt-BR", { day: "2-digit", month: "2-digit", year: "2-digit" }).format(new Date(iso));
  } catch { return iso.slice(0, 10); }
}

function formatCurrency(v?: number): string {
  if (!v) return "—";
  return new Intl.NumberFormat("pt-BR", { notation: "compact", style: "currency", currency: "BRL", maximumFractionDigits: 1 }).format(v);
}

function Skeleton({ className }: { className?: string }) {
  return <div className={cn("animate-pulse rounded bg-[var(--line)]", className)} />;
}

function TableSkeleton() {
  return (
    <div className="divide-y divide-[var(--line)]">
      {Array.from({ length: 8 }).map((_, i) => (
        <div key={i} className="grid grid-cols-12 gap-4 px-5 py-4">
          <Skeleton className="col-span-1 h-4 w-6" />
          <Skeleton className="col-span-6 h-4" />
          <Skeleton className="col-span-1 h-4 w-8" />
          <Skeleton className="col-span-2 h-4 w-16" />
          <Skeleton className="col-span-2 h-4 w-12" />
        </div>
      ))}
    </div>
  );
}

function ScoreBar({ value }: { value?: number }) {
  if (!value) return <span className="text-sm text-[var(--muted)]">—</span>;
  return (
    <div className="flex items-center gap-2">
      <div className="h-1.5 w-16 overflow-hidden rounded-full bg-[var(--panel2)]">
        <div className="h-full rounded-full bg-[var(--gold)]" style={{ width: `${value}%` }} />
      </div>
      <span className="tabular-nums text-sm font-bold text-[var(--text)]">{value}</span>
    </div>
  );
}

function LineRow({ op, rank, onClick, active }: { op: Oportunidade; rank: number; onClick: () => void; active: boolean }) {
  const dias = diasRestantes(op.data_encerramento_proposta);
  const diasCls = dias <= 1 ? "text-red-400 font-bold" : dias <= 5 ? "text-amber-400 font-semibold" : "text-[var(--muted)]";
  return (
    <div
      onClick={onClick}
      className={cn(
        "group grid grid-cols-12 items-center gap-4 border-b border-[var(--line)] px-5 py-4 transition-colors cursor-pointer",
        active ? "bg-[var(--panel-gold)]" : "hover:bg-[var(--panel-soft)]"
      )}
    >
      <span className="col-span-1 text-sm font-semibold text-[var(--muted)]">{rank}</span>
      <div className="col-span-6 min-w-0">
        <p className={cn("truncate text-sm font-semibold transition-colors", active ? "text-[var(--gold)]" : "text-[var(--text)] group-hover:text-[var(--gold)]")}>
          {op.objeto_compra}
        </p>
        {op.razao_social_orgao && (
          <p className="mt-0.5 truncate text-xs text-[var(--muted)]">{op.razao_social_orgao}</p>
        )}
      </div>
      <span className="col-span-1 text-xs font-bold text-[var(--muted)]">{op.uf}</span>
      <div className="col-span-2">
        <span className={cn("text-sm", diasCls)}>{dias <= 0 ? "Enc." : `D-${dias}`}</span>
        <p className="text-[11px] text-[var(--muted)]">{formatDate(op.data_encerramento_proposta)}</p>
      </div>
      <div className="col-span-2">
        <ScoreBar value={op.score_oportunidade} />
      </div>
    </div>
  );
}

function DetalhePanel({ op, onClose }: { op: Oportunidade; onClose: () => void }) {
  const dias = diasRestantes(op.data_encerramento_proposta);
  return (
    <aside className="flex flex-col gap-6 border-l border-[var(--line)] bg-[var(--panel)] px-6 py-6 w-72 shrink-0">
      <div className="flex items-start justify-between gap-2">
        <p className="text-sm font-bold leading-snug text-[var(--text)]">{op.objeto_compra}</p>
        <button onClick={onClose} className="shrink-0 text-[var(--muted)] hover:text-[var(--text)]">✕</button>
      </div>
      <div className="space-y-4">
        {[
          { label: "Órgão", valor: op.razao_social_orgao || "—" },
          { label: "UF", valor: op.uf },
          { label: "Encerramento", valor: formatDate(op.data_encerramento_proposta) },
          { label: "Prazo", valor: dias <= 0 ? "Encerrado" : `${dias} dias restantes` },
          { label: "Valor estimado", valor: formatCurrency(op.valor_total_estimado) },
          { label: "Modalidade", valor: op.modalidade_nome || "—" },
          ...(op.score_oportunidade != null ? [{ label: "Score", valor: String(op.score_oportunidade) }] : []),
        ].map((f) => (
          <div key={f.label}>
            <p className="text-[10px] font-extrabold uppercase tracking-widest text-[var(--muted)]">{f.label}</p>
            <p className="mt-0.5 text-sm font-semibold text-[var(--text)]">{f.valor}</p>
          </div>
        ))}
      </div>
      {op.numero_controle_pncp && (
        <a
          href={`https://pncp.gov.br/app/editais/${op.numero_controle_pncp}`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1.5 text-xs font-bold text-[var(--gold)] hover:opacity-80 transition-opacity"
        >
          Ver edital no PNCP <ChevronRight className="h-3.5 w-3.5" />
        </a>
      )}
    </aside>
  );
}

function UpgradeBanner({ plano }: { plano: string | null }) {
  return (
    <div className="flex items-center justify-between gap-4 rounded-xl border border-amber-500/20 bg-amber-500/5 px-5 py-4">
      <div className="flex items-center gap-3">
        <TrendingUp className="h-4 w-4 shrink-0 text-amber-400" />
        <p className="text-sm font-semibold text-[var(--text)]">
          Limite do plano <strong className="capitalize">{plano || "Free"}</strong> atingido.
          Faça upgrade para acessar mais oportunidades e UFs.
        </p>
      </div>
      <Button size="sm" className="shrink-0">Upgrade</Button>
    </div>
  );
}

export function RadarPage() {
  const [uf, setUf] = useState("");
  const [q, setQ] = useState("");
  const [selected, setSelected] = useState<Oportunidade | null>(null);

  const { items, loading, error, planLimited, plano, hasMore, refetch, loadMore } =
    useOportunidades({ uf: uf || undefined, q: q || undefined });

  const { plano: planoInfo } = usePlano();

  const scoreMedia = useMemo(() => {
    const scored = items.filter((i) => i.score_oportunidade != null);
    if (!scored.length) return null;
    return Math.round(scored.reduce((a, b) => a + (b.score_oportunidade ?? 0), 0) / scored.length);
  }, [items]);

  return (
    <AppShell
      breadcrumb="Dashboard"
      action={
        <Button variant="outline" size="sm" className="gap-2" onClick={refetch}>
          <RefreshCw className="h-3.5 w-3.5" /> Atualizar
        </Button>
      }
    >
      <div className="mx-auto max-w-7xl space-y-6">

        {/* Cabeçalho */}
        <div>
          <h1 className="text-xl font-extrabold tracking-tight text-[var(--text)]">Radar de oportunidades</h1>
          <p className="mt-1 text-sm text-[var(--muted)]">
            Licitações abertas ranqueadas por compatibilidade com o perfil da empresa.
          </p>
        </div>

        {/* Sumário */}
        <div className="flex items-center gap-8">
          <div>
            <div className="text-2xl font-extrabold tabular-nums text-[var(--text)]">
              {loading ? <Skeleton className="h-7 w-8 inline-block" /> : items.length}
            </div>
            <div className="mt-0.5 text-xs font-semibold text-[var(--muted)]">oportunidades encontradas</div>
          </div>
          <div className="h-8 w-px bg-[var(--line)]" />
          <div>
            <div className="text-2xl font-extrabold tabular-nums text-[var(--text)]">
              {loading ? <Skeleton className="h-7 w-8 inline-block" /> : (scoreMedia ?? "—")}
            </div>
            <div className="mt-0.5 text-xs font-semibold text-[var(--muted)]">score médio</div>
          </div>
          {planoInfo && (
            <>
              <div className="h-8 w-px bg-[var(--line)]" />
              <div>
                <div className="text-sm font-extrabold capitalize text-[var(--text)]">{planoInfo.plano}</div>
                <div className="mt-0.5 text-xs font-semibold text-[var(--muted)]">plano atual</div>
              </div>
            </>
          )}
        </div>

        {/* Filtros */}
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Buscar por objeto…"
            className="h-9 max-w-xs bg-[var(--panel)] text-sm"
          />
          <div className="flex flex-wrap gap-1.5">
            {UFS.map((u) => (
              <button
                key={u}
                onClick={() => setUf(u === uf ? "" : u)}
                className={cn(
                  "rounded-lg border px-2.5 py-1 text-xs font-bold transition-colors",
                  u === uf
                    ? "border-[rgba(228,164,20,.4)] bg-[var(--panel-gold)] text-[var(--gold)]"
                    : "border-[var(--line)] bg-[var(--panel)] text-[var(--muted)] hover:text-[var(--text)]"
                )}
              >
                {u === "" ? "Todas" : u}
              </button>
            ))}
          </div>
        </div>

        {planLimited && <UpgradeBanner plano={plano} />}

        {/* Tabela */}
        <div className="flex overflow-hidden rounded-2xl border border-[var(--line)] bg-[var(--panel)]">
          <div className="flex-1 min-w-0">
            {/* Cabeçalho da tabela */}
            <div className="grid grid-cols-12 gap-4 border-b border-[var(--line)] bg-[var(--panel2)] px-5 py-3">
              {[
                { label: "#",       cls: "col-span-1" },
                { label: "Objeto",  cls: "col-span-6" },
                { label: "UF",      cls: "col-span-1" },
                { label: "Enc.",    cls: "col-span-2" },
                { label: "Score",   cls: "col-span-2" },
              ].map((h) => (
                <div key={h.label} className={cn("text-[11px] font-extrabold uppercase tracking-wider text-[var(--muted)]", h.cls)}>
                  {h.label}
                </div>
              ))}
            </div>

            {loading ? (
              <TableSkeleton />
            ) : error ? (
              <div className="flex flex-col items-center gap-3 py-16 text-center">
                <AlertCircle className="h-8 w-8 text-red-400" />
                <p className="text-sm font-semibold text-[var(--muted)]">{error}</p>
                <Button size="sm" variant="outline" onClick={refetch}>Tentar novamente</Button>
              </div>
            ) : items.length === 0 ? (
              <div className="py-16 text-center">
                <p className="text-sm font-semibold text-[var(--muted)]">
                  Nenhuma oportunidade para os filtros selecionados.
                </p>
                <button onClick={() => { setUf(""); setQ(""); }} className="mt-2 text-xs font-bold text-[var(--gold)] hover:opacity-80">
                  Limpar filtros
                </button>
              </div>
            ) : (
              <>
                {items.map((op, i) => (
                  <LineRow
                    key={op.id_pncp ?? op.numero_controle_pncp ?? i}
                    op={op}
                    rank={i + 1}
                    active={selected?.id_pncp === op.id_pncp}
                    onClick={() => setSelected(selected?.id_pncp === op.id_pncp ? null : op)}
                  />
                ))}
                {hasMore && !planLimited && (
                  <div className="border-t border-[var(--line)] px-5 py-4">
                    <button onClick={loadMore} className="text-xs font-bold text-[var(--gold)] hover:opacity-80 transition-opacity">
                      Carregar mais →
                    </button>
                  </div>
                )}
              </>
            )}
          </div>

          {selected && <DetalhePanel op={selected} onClose={() => setSelected(null)} />}
        </div>
      </div>
    </AppShell>
  );
}
