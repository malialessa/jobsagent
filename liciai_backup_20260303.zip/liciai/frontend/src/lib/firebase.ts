import { initializeApp, getApps } from "firebase/app";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyDqRoRHQU-3XwUmNrV5MwVW6o_PwbxywVA",
  authDomain: "uniquex-487718.firebaseapp.com",
  projectId: "uniquex-487718",
  storageBucket: "uniquex-487718.firebasestorage.app",
  messagingSenderId: "1050359786854",
  appId: "1:1050359786854:web:6b9c09acbbd637ed5a6ca7",
};

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];
export const auth = getAuth(app);
