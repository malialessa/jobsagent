import { auth } from "@/lib/firebase";

// Em produção a URL é relativa (/api) → Firebase Hosting faz proxy para a Cloud Function
// sem expor URL direta e sem CORS. Em dev local crie frontend/.env.local:
//   VITE_API_BASE=http://127.0.0.1:5001/uniquex-487718/us-east1/api
export const API_BASE: string = import.meta.env.VITE_API_BASE || "/api";

// ─── Helper genérico ─────────────────────────────────────────────────────────

async function apiFetch<T>(
  path: string,
  options: RequestInit = {}
): Promise<T> {
  const token = await auth.currentUser?.getIdToken();
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...(options.headers as Record<string, string>),
  };
  if (token) headers["Authorization"] = `Bearer ${token}`;

  const res = await fetch(`${API_BASE}${path}`, { ...options, headers });

  if (!res.ok) {
    let errBody: any;
    try {
      errBody = await res.json();
    } catch {
      errBody = { message: res.statusText };
    }
    const err = new ApiError(
      errBody?.error?.message || errBody?.message || "Erro desconhecido",
      res.status,
      errBody?.error?.code
    );
    throw err;
  }

  return res.json() as Promise<T>;
}

export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
    public code?: string
  ) {
    super(message);
    this.name = "ApiError";
  }

  get isPlanLimit() {
    return (
      this.status === 403 &&
      (this.code === "QUOTA_EXCEEDED" ||
        this.code === "UF_LIMIT_EXCEEDED" ||
        this.code === "PLAN_INACTIVE")
    );
  }
}

// ─── Tipos ────────────────────────────────────────────────────────────────────

export interface Oportunidade {
  id_pncp?: string;
  numero_controle_pncp?: string;
  objeto_compra: string;
  uf: string;
  data_encerramento_proposta: string;
  valor_total_estimado?: number;
  modalidade_nome?: string;
  score_oportunidade?: number;
  razao_social_orgao?: string;
}

export interface OportunidadesResponse {
  items: Oportunidade[];
  nextOffset: number | null;
  plano?: string;
}

export interface PlanoLimites {
  uf: number;
  oportunidades: number;
  docs: number;
  produtos: number;
}

export interface PlanoInfo {
  plano: "free" | "pro" | "enterprise" | "gov";
  status_pagamento: string;
  limites: PlanoLimites;
  tenant_id: string;
}

export interface PalavraChave {
  palavra_chave: string;
  peso: number;
}

export interface ConfiguracoesResponse {
  palavrasChave: PalavraChave[];
}

// ─── Endpoints ────────────────────────────────────────────────────────────────

export const api = {
  /** Retorna oportunidades ranqueadas por score para o usuário autenticado. */
  getScoredOportunidades(params: {
    uf?: string;
    q?: string;
    limit?: number;
    offset?: number;
  }) {
    const sp = new URLSearchParams();
    if (params.uf) sp.set("uf", params.uf);
    if (params.q) sp.set("q", params.q);
    if (params.limit) sp.set("limit", String(params.limit));
    if (params.offset) sp.set("offset", String(params.offset));
    const qs = sp.toString() ? `?${sp.toString()}` : "";
    return apiFetch<OportunidadesResponse>(`/getScoredOportunidades${qs}`);
  },

  /** Oportunidades públicas (sem score personalizado). */
  getOportunidades(params: { uf?: string; q?: string; limit?: number; offset?: number }) {
    const sp = new URLSearchParams();
    if (params.uf) sp.set("uf", params.uf);
    if (params.q) sp.set("q", params.q);
    if (params.limit) sp.set("limit", String(params.limit));
    if (params.offset) sp.set("offset", String(params.offset));
    const qs = sp.toString() ? `?${sp.toString()}` : "";
    return apiFetch<OportunidadesResponse>(`/getOportunidades${qs}`);
  },

  /** Informações do plano do usuário autenticado. */
  getPlanoAtual() {
    return apiFetch<PlanoInfo>("/getPlanoAtual");
  },

  /** Palavras-chave e pesos de filtro do usuário. */
  getClienteConfiguracoes() {
    return apiFetch<ConfiguracoesResponse>("/getClienteConfiguracoes");
  },

  /** Adiciona ou atualiza uma palavra-chave de filtro. */
  addPalavraChave(palavraChave: string, peso = 1) {
    return apiFetch<{ success: boolean }>("/addPalavraChave", {
      method: "POST",
      body: JSON.stringify({ palavraChave, peso }),
    });
  },

  /** Remove uma palavra-chave de filtro. */
  removePalavraChave(palavraChave: string) {
    return apiFetch<{ success: boolean }>("/removePalavraChave", {
      method: "POST",
      body: JSON.stringify({ palavraChave }),
    });
  },

  /** Detalhes completos de uma oportunidade (payload bruto PNCP). */
  getDetalhesOportunidade(id: string) {
    return apiFetch<Record<string, any>>(`/getDetalhesOportunidade?id=${encodeURIComponent(id)}`);
  },

  /** Registra erro de frontend no BigQuery. */
  logError(mensagem: string, extra?: Record<string, any>) {
    return apiFetch<{ message: string }>("/logError", {
      method: "POST",
      body: JSON.stringify({ mensagem, ...extra }),
    });
  },
};
