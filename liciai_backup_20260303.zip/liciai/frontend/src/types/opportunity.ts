export interface Opportunity {
  numeroControlePNCP: string;
  objeto_compra: string;
  uf: string;
  score_oportunidade?: number;
}
